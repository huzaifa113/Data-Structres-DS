#pragma once

//Huffmann prototypes, headerFile


//to create a minimum heap binary tree for the purpose of storing huffmann codes
struct MinimumHeapNode
{
	char data;
	int frequency;
	MinimumHeapNode* left, * right;
	MinimumHeapNode(char d, int freq)
	{
		data = d;
		frequency = freq;
		left = nullptr;
		right = nullptr;
	}
};

//this struct is created so as to have minimum heap priority queue as by default, C++ STL uses max heap 
struct compare
{
	bool operator()(MinimumHeapNode* l, MinimumHeapNode* r)
	{
		return (l->frequency > r->frequency);		//comparing frequency of left and right childs
	}
};



void storeCodesInMap(MinimumHeapNode* root, string str);
void storeCodeInFile(string str, string file);
void HuffmanEncoding(string text);
string HuffmannDecoding(MinimumHeapNode* root, string file);
string Decoding(string file);



