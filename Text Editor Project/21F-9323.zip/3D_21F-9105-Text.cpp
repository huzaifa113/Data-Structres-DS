#include "HeaderFiles.h"
#include "SuffixTree.h"
#include "Huffmann.h"
#include "Text.h"

void menu(int msg, SuffixTree dictionaryTree)
{
	system("CLS");
	if (msg == 0)
	{
		cout << "Welcome to Text Editor" << endl << endl;
	}
	if (msg == 1)
	{
		cout << "File Created Successfully" << endl << endl;
	}
	if (msg == 2)
	{
		cout << "File Updated Successfully" << endl << endl;
	}
	if (msg == 4)
	{
		cout << "File Emptied Successfully" << endl << endl;
	}
	if (msg == 5)
	{
		cout << "File Deleted Successfully" << endl << endl;
	}
	if (msg == 55)
	{
		cout << "File Not Found" << endl << endl;
	}
	if (msg == 6)
	{
		cout << "File Copied Successfully" << endl << endl;
	}

	cout << "Main Menu" << endl;
	cout << "-------------" << endl;
	cout << "1. Create File" << endl;
	cout << "2. Add to File" << endl;
	cout << "3. Read from File" << endl;
	cout << "4. Empty File" << endl;
	cout << "5. Delete File" << endl;
	cout << "6. Copy File" << endl;
	cout << "7. Exit" << endl << endl;
	cout << "Enter Choice: ";

	int choice = 0;
	string filename;
	string text;

	cin >> choice;
	if (choice == 1)
	{
		cout << endl << "Enter name of file: ";
		cin.ignore();
		getline(cin, filename);
		ofstream myfile((filename + ".txt").c_str());	//.c_str() is used when you want to pass the contents of string to function//
		myfile.close();
		menu(1, dictionaryTree);
		cin >> choice;
	}
	if (choice == 2)
	{
		text = "";
		cout << endl << "Enter name of file: ";
		cin >> filename;
		ifstream obj(filename + "txt");
		string temp = "-1";
		obj >> temp;
		if (temp != "-1")
		{
			text = Decoding(filename);
		}
		cout << endl << "Enter text to write to file: (Enter = to save as compressed) or (Enter / to show suggestion of current word)" << endl;
		cout << text;
		string line;
		cin.ignore();	 // (Ignore the Buffer(Temperory contents)	
		while (getline(cin, line))
		{
			if (line.size() >= 1)
			{
				if (line[line.size() - 1] == '=') //Specifying that whenever = is typed stop reading data eof//
				{
					text += line.substr(0, line.size() - 1);// 0 is position of 1st chracter ,line.size is the total length, 1 is size of =//
					HuffmanEncoding(text);
					system("CLS");
					cout << "Data is saved in compressed form as: ";
					storeCodeInFile(text, filename);
					Sleep(2500);
					break;		//stop taking input and break loop 79
				}
				else if (line[line.size() - 1] == '/')
				{
					int indexForSpace = 0;
					line = line.substr(0, line.size() - 1);
					stack<char> s;
					string temp = "";
					for (int i = line.size(); i > 0; i--)
					{
						if (line[i] != ' ')
						{
							s.push(line[i]);
							indexForSpace++;
						}
						else
						{
							indexForSpace--;
							break;		//break from for loop
						}
					}
					while (!s.empty())
					{
						temp += s.top();
						s.pop();
					}
					bool flag = false;
					string suggestion = "";
					string toPrint = "";
					if (dictionaryTree.checkSuggestions(temp, suggestion) == 1 )
					{
						char smallInput = ' ';
						int j = 0;
						for (int i = 0; i < 10; i++)
						{
							system("CLS");
							cout << "Suggestion " << i + 1 << ": ";
							for (; suggestion[j] != ' ' || suggestion[j] == '\0'; j++)
							{
								cout << suggestion[j];
								toPrint += suggestion[j];
							}
							j++;
							cout << endl << "Enter ; to select current suggestion or / to move to next Suggestion" << endl;
							cout << line;
							cin >> smallInput;
							if (smallInput == '/')
							{
								toPrint = "";
								continue;		//conitnue for loop
							}
							else if (smallInput == ';')
							{
								flag = true;
								//line = line.substr(0, line.size() - 1);
								text += line.substr(0, line.size() - (indexForSpace));
								text += toPrint;
								break;			//break from for loop
							}
							else
							{
								i--;
								cout << endl << "Wrong Input, try again" << endl;
								Sleep(1000);
							}
						}
						cout << "Suggestions completed or added " << endl;
						if (!flag)
							text += line;
						system("CLS");
						cout << endl << "Enter text to write to file: (Enter = to save as compressed) or (Enter / to show suggestion of current word)" << endl;
						cout << text;
						line = "";
						continue;			//continue taking input 
					}
				}
			}
			else 
			{
				text += line + "\n";
			}
		}
		menu(2, dictionaryTree);
		cin >> choice;
	}
	if (choice == 3)
	{
		text = "";
		cout << endl << "Enter name of file: ";
		cin >> filename;
		text = Decoding(filename);
		cout << text << endl;
		char now;
		cout << endl << "End of File. Press any key for main menu: ";
		cin >> now;
		menu(2, dictionaryTree);
		cin >> choice;
	}
	if (choice == 4)
	{
		cout << endl << "Enter name of file: ";
		cin >> filename;
		ofstream myfile;
		myfile.open((filename + ".txt").c_str());
		myfile << "";
		myfile.close();
		menu(4, dictionaryTree);
		cin >> choice;
	}
	if (choice == 5)
	{
		cout << endl << "Enter name of file: ";
		cin >> filename;
		if (remove((filename + ".txt").c_str()) == 0)
		{
			menu(5, dictionaryTree);
		}
		else
		{
			menu(55, dictionaryTree);
		}
	}
	if (choice == 6)
	{
		text = "";
		cout << endl << "Enter name of file to copy from: ";
		cin.ignore();
		getline(cin, filename);
		fstream myfile((filename + ".txt").c_str());
		string line;
		while (getline(myfile, line)) {
			text += line + "\n";
		}
		myfile.close();
		cout << endl << "Enter name of file to copy to: ";
		string second;
		getline(cin, second);
		ofstream myfile2;
		myfile2.open((second + ".txt").c_str(), ios::app);
		myfile2 << text;
		myfile2.close();
		menu(6, dictionaryTree);
		cin >> choice;
	}
	if (choice == 7)
	{
		exit(EXIT_SUCCESS);
	}
}
