#pragma once

//Suffix, trie tree HeaderFile

#define ALPHA_SIZE 26

class SuffixTree
{

	SuffixTree* alphabets[ALPHA_SIZE];
	bool redFlag;
public:
	SuffixTree();
	void insertInSuffix(const string word);
	bool lastLevelExists(SuffixTree* level);
	int checkSuggestions(const string forSuggest, string& suggestions);
	string returnSuggestion(SuffixTree* level, string currentWord, string& suggestions);
	SuffixTree* returnLevel();
};
