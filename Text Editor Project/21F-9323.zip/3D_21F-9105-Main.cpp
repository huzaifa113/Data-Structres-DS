#include "HeaderFiles.h"
#include "SuffixTree.h"
#include "Text.h"

int main()
{
	SuffixTree dictionaryTree;
	ifstream dictionary("dictionary.txt");
	string words = "";
	while (getline(dictionary, words))
	{
		dictionaryTree.insertInSuffix(words);
	}
	menu(0, dictionaryTree);
	system("pause");
	return 0;
}