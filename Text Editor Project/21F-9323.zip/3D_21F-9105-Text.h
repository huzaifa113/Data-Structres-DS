#pragma once
#include "SuffixTree.h"

//text editor prototype
void menu(int, SuffixTree dictionaryTree);