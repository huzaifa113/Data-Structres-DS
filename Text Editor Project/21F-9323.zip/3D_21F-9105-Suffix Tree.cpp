#include "HeaderFiles.h"
#include "SuffixTree.h"


SuffixTree::SuffixTree()
{
	redFlag = false;
	for (int i = 0; i < ALPHA_SIZE; i++)
	{
		alphabets[i] = nullptr;
	}
}
void SuffixTree::insertInSuffix(const string word)
{
	SuffixTree* temp = this;		//pointing to root, this means the object of which the function is called
	int alphabetIndex = 0;
	for (int characterIndex = 0; characterIndex < word.length(); characterIndex++)
	{
		alphabetIndex = word[characterIndex] - 'a';		//converting alphabetIndex to have the integer value of the word's letter, for example b is converted to 1 etc (98-97 ASCII)
		if (temp->alphabets[alphabetIndex] == NULL)
			temp->alphabets[alphabetIndex] = new SuffixTree;

		temp = temp->alphabets[alphabetIndex];
	}
	temp->redFlag = true;
}
bool SuffixTree::lastLevelExists(SuffixTree* level)
{
	for (int i = 0; i < ALPHA_SIZE; i++)
	{
		if (level->alphabets[i])
			return 1;
	}
	return 0;
}
int SuffixTree::checkSuggestions(const string forSuggest, string& suggestions)
{
	SuffixTree* temp = this;		//traversal
	int alphabetIndex = 0;
	for (int characterIndex = 0; characterIndex < forSuggest.length() - 1; characterIndex++)
	{
		alphabetIndex = forSuggest[characterIndex] - 'a';		//converting alphabetIndex to have the integer value of the word's letter, for example b is converted to 1 etc (98-97 ASCII)
		if (!temp->alphabets[alphabetIndex])
			return 0;		//the word to suggest for does not exist in Dictionary, it is either special or name

		temp = temp->alphabets[alphabetIndex];
	}
	//checking whether a suggestion for the word exists even if it is in the Dictionary, checking the next level of the last character
	bool lastLevelExists = false;
	for (int i = 0; i < ALPHA_SIZE && (!lastLevelExists); i++)
	{
		if (temp->alphabets[i])
			lastLevelExists = true;
	}
	if (!lastLevelExists)
		return -1;				//suggestion does not exist

	suggestions = returnSuggestion(temp, forSuggest, suggestions);

	return 1;
}

string SuffixTree::returnSuggestion(SuffixTree* level, string currentWord, string& suggestions)
{
	if (level->redFlag == true)
	{
		suggestions += currentWord + " ";			//space to differentiate between different suggestion
	}

	char nextLetter = ' ';
	for (int i = 0; i < ALPHA_SIZE; i++)
	{
		if (level->alphabets[i])
		{
			nextLetter = 'a' + i;		//converting index to character, if index is 1 then b character, (97+1)
			returnSuggestion(level->alphabets[i], currentWord + nextLetter, suggestions);			//nextLetter of suggestion will be added in the currentWord, if ba is currentWord then, bat will be added
		}
	}
	return suggestions;
}

SuffixTree* SuffixTree::returnLevel()
{
	return this;
}