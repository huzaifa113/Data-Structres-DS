#pragma once

#include <iostream>
#include <string>
#include <queue>
#include <stack>
#include <map>
#include <vector>
#include <iterator>
#include <fstream>
#include <Windows.h>

using namespace std;








