//#include <iostream>
//#include <string>
//#include <queue>
//#include <map>
//#include <vector>
//#include <iterator>
//#include <fstream>
//
//using namespace std;
//
//struct MinimumHeapNode;
//struct compare;
//
//Global Maps
//map<char, int> frequencyOf;			//this will store the character and its frequency respectively
//map<char, string> huffmannCode;		//this will store the character and its huffmann encoded string that is, 1100 or 0011 etc
//
//
//to create a minimum heap binary tree for the purpose of storing huffmann codes
//struct MinimumHeapNode
//{
//	char data;
//	int frequency;
//	MinimumHeapNode* left, * right;
//	MinimumHeapNode(char d, int freq)
//	{
//		data = d;
//		frequency = freq;
//		left = nullptr;
//		right = nullptr;
//	}
//};
//
//this struct is created so as to have minimum heap priority queue as by default, C++ STL uses max heap 
//struct compare
//{
//	bool operator()(MinimumHeapNode* l, MinimumHeapNode* r)
//	{
//		return (l->frequency > r->frequency);		//comparing frequency of left and right childs
//	}
//};
//
//void storeCodesInMap(MinimumHeapNode* root, string str)
//{
//	if (!root)
//		return;
//	if (root->data != '!')					//! is a sentinel value, meaning the root is not a leaf node, rather internal node
//		huffmannCode[root->data] = str;		//if condition shows that str will have the huffmann code accordingly of the character
//
//	storeCodesInMap(root->left, str +"0");		//left storage so adding 0 in the string to show huffmann code
//	storeCodesInMap(root->right, str + "1");	//right storage so adding 1 in the string to show huffmann code
//}
//
//void storeCodeInFile(string str, string file)
//{
//	string temp;
//	ofstream obj((file + ".txt"));
//	for (int i = 0; i < str.size(); i++)
//	{
//		temp += huffmannCode[str[i]];
//	}
//	obj << temp << "\n";
//	obj.close();
//	cout << temp << endl;
//}
//
//Global Priority Queue
//priority_queue<MinimumHeapNode*, vector<MinimumHeapNode*>, compare> priorityQueue;		//this will create the Huffmann Tree using MinimumHeapNode
//
//void HuffmanEncoding(string text)
//{
//	for (int i = 0; i < text.size(); i++)
//	{
//		frequencyOf[text[i]]++;			//incrementing frequency of each character given in text
//	}
//	MinimumHeapNode* left, * right, * tempMem;		//left right storing nodes and tempMem is to allocate memory to assign accordingly
//
//	map<char, int> ::iterator it = frequencyOf.begin();
//	while (it != frequencyOf.end())
//	{
//		priorityQueue.push(new MinimumHeapNode(it->first, it->second));		//allocating new memory untill frequencyOf has ended and pushing in priorityQueue
//		it++;					//incrementing iterator
//	}
//
//	while (priorityQueue.size() != 1)
//	{
//		left = priorityQueue.top();
//		priorityQueue.pop();
//		right = priorityQueue.top();
//		priorityQueue.pop();
//		tempMem = new MinimumHeapNode('!', left->frequency + right->frequency);		//total frequency of an internal node
//		tempMem->left = left;
//		tempMem->right = right;
//		priorityQueue.push(tempMem);
//	}
//	storeCodesInMap(priorityQueue.top(), "");			//storing Codes in priority Queue in map
//}
//
//string HuffmannDecoding(MinimumHeapNode* root, string file)
//{
//	ifstream obj((file + ".txt"));
//	string temp;
//	obj >> temp;
//	
//	obj.close();
//	string output = "";
//	MinimumHeapNode* current = root;
//	for (int i = 0; i < temp.size(); i++)
//	{
//		if (temp[i] == '0')
//			current = current->left;
//		else
//			current = current->right;
//
//		if (!current->left && !current->right)
//		{
//			output += current->data;
//			current = root;
//		}
//	}
//	return (output + '\0');
//}
//
//int main()
//{
//	cout << "Enter an test sentence to check for Huffmann: ";
//	string str;
//	getline(cin, str);
//
//	HuffmanEncoding(str);
//	storeCodeInFile(str, "123");
//	cout << HuffmannDecoding(priorityQueue.top(), "123") << endl;
//
//	system("pause");
//	return 0;
//}