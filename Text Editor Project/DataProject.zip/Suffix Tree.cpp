//#include <iostream>
//#include <string>
//#include <stack>
//#include <fstream>
//
//#define ALPHA_SIZE 26
//
//using namespace std;
//
//class SuffixTree
//{
//
//	SuffixTree* alphabets[ALPHA_SIZE];		
//	bool redFlag;
//public:
//	SuffixTree()
//	{
//		redFlag = false;
//		for (int i = 0; i < ALPHA_SIZE; i++)
//		{
//			alphabets[i] = nullptr;
//		}
//	}
//	void insertInSuffix(const string word)
//	{
//		SuffixTree* temp = this;		//pointing to root, this means the object of which the function is called
//		int alphabetIndex = 0;
//		for (int characterIndex = 0; characterIndex < word.length(); characterIndex++)
//		{
//			alphabetIndex = word[characterIndex] - 'a';		//converting alphabetIndex to have the integer value of the word's letter, for example b is converted to 1 etc (98-97 ASCII)
//			if (temp->alphabets[alphabetIndex] == NULL)
//				temp->alphabets[alphabetIndex] = new SuffixTree;
//
//			temp = temp->alphabets[alphabetIndex];
//		}
//		temp->redFlag = true;
//	}
//	bool lastLevelExists(SuffixTree* level)
//	{
//		for (int i = 0; i < ALPHA_SIZE; i++)
//		{
//			if (level->alphabets[i])
//				return 1;
//		}
//		return 0;
//	}
//	int checkSuggestions(const string forSuggest)	
//	{
//		SuffixTree* temp = this;		//traversal
//		int alphabetIndex = 0;
//		for (int characterIndex = 0; characterIndex < forSuggest.length(); characterIndex++)
//		{
//			alphabetIndex = forSuggest[characterIndex] - 'a';		//converting alphabetIndex to have the integer value of the word's letter, for example b is converted to 1 etc (98-97 ASCII)
//			if (!temp->alphabets[alphabetIndex])
//				return 0;		//the word to suggest for does not exist in Dictionary, it is either special or name
//
//			temp = temp->alphabets[alphabetIndex];
//		}
//		//checking whether a suggestion for the word exists even if it is in the Dictionary, checking the next level of the last character
//		bool lastLevelExists = false;
//		for (int i = 0; i < ALPHA_SIZE && (!lastLevelExists); i++)
//		{
//			if (temp->alphabets[i])
//				lastLevelExists = true;
//		}
//		if (!lastLevelExists)
//			return -1;				//suggestion does not exist
//
//		printSuggestions(temp, forSuggest);
//		return 1;
//	}
//
//	void printSuggestions(SuffixTree* level, string currentWord)	
//	{
//		if (level->redFlag == true)
//			cout << currentWord << endl;
//
//		char nextLetter = ' ';
//		for (int i = 0; i < ALPHA_SIZE; i++)
//		{
//			if (level->alphabets[i])
//			{
//				nextLetter = 'a' + i;		//converting index to character, if index is 1 then b character, (97+1)
//				printSuggestions(level->alphabets[i], currentWord + nextLetter);			//nextLetter of suggestion will be added in the currentWord, if ba is currentWord then, bat will be added
//			}
//		}
//	}
//};
//
//int main()
//{
//	SuffixTree obj;
//	ifstream dictionary("dictionary.txt");
//	string words = "";
//	while (getline(dictionary, words))
//	{
//		obj.insertInSuffix(words);
//	}
//  cout<<"Enter a word to find its suggestions (like associat): ";
//  cin>>words;
//	obj.checkSuggestions(words);
//
//	system("pause");
//	return 0;
//}