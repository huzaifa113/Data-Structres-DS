//#include <iostream>
//
//#include "Text.h"
//
//int main()
//{
//	menu(0);
//	system("pause");
//	return 0;
//}